<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>">Home</a></li>
                        <li class="breadcrumb-item"><a
                                href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/pengantar"><?=$title?></a>
                        </li>
                        <li class="breadcrumb-item"><a
                                href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/mahasiswa/index"><?=$table?></a>
                        </li>
                        <li class="breadcrumb-item active"><?=$view?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?= $judul ?></h3>

                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right"
                                        placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" name="submit_search" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-2">
                            <div class="row">
                                <div class="col-6 p-4">
                                    <table class="table table-striped text-nowrap">
                                        <tbody>
                                            <tr>
                                                <td>NIM</td>
                                                <td>:</td>
                                                <td><?= $mhs->nim ?></td>
                                            </tr>
                                            <tr>
                                                <td>Nama Lengkap</td>
                                                <td>:</td>
                                                <td><?= $mhs->nama ?></td>
                                            </tr>
                                            <tr>
                                                <td>Gender</td>
                                                <td>:</td>
                                                <td><?= $mhs->gender ?></td>
                                            </tr>
                                            <tr>
                                                <td>Tempat, Tanggal Lahir</td>
                                                <td>:</td>
                                                <td><?= $mhs->tmp_lahir ?>, <?= $mhs->tgl_lahir ?></td>
                                            </tr>
                                            <tr>
                                                <td>IPK</td>
                                                <td>:</td>
                                                <td><?= $mhs->ipk ?></td>
                                            </tr>
                                            <tr>
                                                <td>Prodi</td>
                                                <td>:</td>
                                                <td><?= $mhs->prodi_kode ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-6">
                                    <?php
                                        $hidden = array('idupdate' => $mhs->nim);
                                        echo form_open("praktikum/praktikum_9/mahasiswa/save", array('class' => 'form-horizontal p-4'), $hidden);
                                    ?>
                                        <div class="form-group row">
                                            <label for="nim" class="col-4 col-form-label">NIM</label>
                                            <div class="col-8">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fa fa-address-card"></i>
                                                        </div>
                                                    </div>
                                                    <input id="nim" name="nim" placeholder="NIM" type="number"
                                                        value="<?= $mhs->nim ?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
                                            <div class="col-8">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fa fa-align-left"></i>
                                                        </div>
                                                    </div>
                                                    <input id="nama" name="nama" placeholder="Nama Lengkap" type="text"
                                                        value="<?= $mhs->nama ?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-4">Jenis Kelamin</label>
                                            <div class="col-8">
                                                <?php
                                                    $checked_l = ($mhs->gender=="L")?"checked":"";
                                                    $checked_p = ($mhs->gender=="P")?"checked":"";
                                                ?>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="jk" id="jk_0" type="radio" class="custom-control-input"
                                                        value="L" <?= $checked_l ?>>
                                                    <label for="jk_0" class="custom-control-label">Laki-laki</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="jk" id="jk_1" type="radio" class="custom-control-input"
                                                        value="P" <?= $checked_p ?>>
                                                    <label for="jk_1" class="custom-control-label">Perempuan</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label>
                                            <div class="col-8">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fa fa-anchor"></i>
                                                        </div>
                                                    </div>
                                                    <input id="tmp_lahir" name="tmp_lahir" type="text"
                                                        value="<?= $mhs->tmp_lahir ?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label>
                                            <div class="col-8">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fa fa-calendar"></i>
                                                        </div>
                                                    </div>
                                                    <input id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir"
                                                        value="<?= $mhs->tgl_lahir ?>" type="date" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="prodi" class="col-4 col-form-label">Program Studi</label>
                                            <div class="col-8">
                                                <select id="prodi" name="prodi" class="custom-select required">
                                                    <option value="">Pilih Prodi ....</option>
                                                    <option value="TI">Teknik Informatika</option>
                                                    <option value="SI">Sistem Informasi</option>
                                                    <option value="BD">Bisnis Digital</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="ipk" class="col-4 col-form-label">IPK</label>
                                            <div class="col-8">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fa fa-book"></i>
                                                        </div>
                                                    </div>
                                                    <input id="ipk" name="ipk" placeholder="IPK" type="number"
                                                        value="<?= $mhs->ipk ?>" step="any" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="offset-4 col-8">
                                                <button name="submit" type="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- Footer -->
<?php $this->load->view('layout/footer') ?>

<!-- JS -->
<?php $this->load->view('layout/js') ?>