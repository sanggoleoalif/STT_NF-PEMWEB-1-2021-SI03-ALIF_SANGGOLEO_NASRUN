<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/pengantar"><?= $title ?></a></li>
                        <li class="breadcrumb-item active"> <?= $table ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?= $judul ?></h3>

                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right"
                                        placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" name="submit_search" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap text-center">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIDN</th>
                                        <th>Nama Dosen</th>
                                        <th>Gender</th>
                                        <th>Tempat, Tanggal Lahir</th>
                                        <th>Prodi</th>
                                        <th>Selengkapnya..</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $nomor = 1;
                                        foreach($list_dsn as $obj) {
                                            echo '<tr>';
                                            echo '<td>'. $nomor .'</td>';
                                            echo '<td>'. $obj->nidn.'</td>';
                                            echo '<td>'. $obj->nama .'</td>';
                                            echo '<td>'. $obj->gender .'</td>';
                                            echo '<td>'. $obj->tmp_lahir. ', ' .$obj->tgl_lahir .'</td>';
                                            echo '<td>'. $obj->prodi_kode .'</td>';
                                            echo '<td> <a class="btn btn-primary btn-sm" href="'. base_url("index.php").'/praktikum/praktikum_9/dosen/view?id='.$obj->nidn .'"><i class="fas fa-eye"></i> View</a></td>';
                                            echo '<td>';
                                            echo '<a class="btn btn-info btn-sm" href="'. base_url("index.php").'/praktikum/praktikum_9/dosen/update?id='.$obj->nidn .'"><i class="fas fa-pencil-alt"></i> Edit</a>';
                                    ?>
                                            <a class="btn btn-danger btn-sm" href="<?= base_url('index.php').'/praktikum/praktikum_9/dosen/delete?id='.$obj->nidn?>"
                                            onclick="if(!confirm('Anda Yakin Akan Menghapus Dosen Dengan NIDN <?= $obj->nidn?>?')) {return false}"><i class="fas fa-trash"></i> Delete</a>
                                    <?php
                                            echo '</td>';
                                            echo '</tr>';
                                            $nomor++;
                                        }
                                    ?>
                                </tbody>
                            </table>
                            <a href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/dosen/form" class="btn btn-primary mt-2 mb-3 ml-4" role="button">Tambah Data Dosen</a>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- Footer -->
<?php $this->load->view('layout/footer') ?>

<!-- JS -->
<?php $this->load->view('layout/js') ?>