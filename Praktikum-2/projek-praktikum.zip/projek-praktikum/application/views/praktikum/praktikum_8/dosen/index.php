<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_8/pengantar"><?= $title ?></a></li>
                        <li class="breadcrumb-item active"> <?= $table ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?= $judul ?></h3>

                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right"
                                        placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" name="submit_search" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap text-center">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIM</th>
                                        <th>Nama Dosen</th>
                                        <th>Gender</th>
                                        <th>Tempat, Tanggal Lahir</th>
                                        <th>Prodi</th>
                                        <th>Selengkapnya..</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $nomor = 1;
                                        foreach($list_dsn as $obj) {
                                            echo '<tr>';
                                            echo '<td>'. $nomor .'</td>';
                                            echo '<td>'. $obj->nidn.'</td>';
                                            echo '<td>'. $obj->nama .'</td>';
                                            echo '<td>'. $obj->gender .'</td>';
                                            echo '<td>'. $obj->tmp_lahir. ', ' .$obj->tgl_lahir .'</td>';
                                            echo '<td>'. $obj->prodi_kode .'</td>';
                                            echo '<td> <a class="btn btn-info btn-sm" href="'. base_url("index.php").'/praktikum/praktikum_8/dosen/view?id='.$obj->nidn .'"><i class="fas fa-eye"></i></a></td>';
                                            echo '</tr>';
                                            $nomor++;
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- Footer -->
<?php $this->load->view('layout/footer') ?>

<!-- JS -->
<?php $this->load->view('layout/js') ?>