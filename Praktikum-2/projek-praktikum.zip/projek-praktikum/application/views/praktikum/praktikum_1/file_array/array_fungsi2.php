<!-- Meta -->
<?php $this->load->view('layout/meta') ?>
<style>
    .d-flex {
        display: flex;
        justify-content: space-evenly;
        
    }
    .bagian {
        width: 25%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        text-align: center;
    }
    ul, li.bagian{
        padding: 1px;
        list-style: none;
    }
</style>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>

<!-- Main -->
<div class="wrapper">

    <div class="content-wrapper" style="min-height: 2838.8px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?= $title ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_1/pengantar"><?= $title ?></a></li>
                            <li class="breadcrumb-item active"> <?= $judul?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?= $title ?></h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex">
                        <div class="bagian">
                            <!-- Fungsi Array Pop -->
                            <?php
                                echo '<h5>Array Pop</h5>';
                                $tims = ["Julmy","Ucup","Jali","Nopall"];
                                array_pop($tims);
                                foreach($tims as $person) {
                                    echo '<ul>';
                                    echo '<li>'.$person . '</li>';
                                    echo '</ul>';
                                }
                            ?>
                            <hr>
                            <!-- Fungsi Array Push -->
                            <?php
                                echo '<h5>Array Push</h5>';
                                $tims = ["Julmy","Ucup","Jali","Nopall"];
                                array_push($tims,'Thalhah');
                                foreach($tims as $person) {
                                    echo '<ul>';
                                    echo '<li>'.$person . '</li>';
                                    echo '</ul>';
                                }
                            ?>
                        </div>
                        <div class="bagian">
                            <!-- Fungsi Shift Array -->
                            <?php
                                echo '<h5>Shift Array</h5>';
                                $tims = ["Kelinci","Ayam","Kucing","Ular"];
                                array_shift($tims);
                                foreach($tims as $person) {
                                    echo '<ul>';
                                    echo '<li>'.$person . '</li>';
                                    echo '</ul>';
                                }
                            ?>
                            <hr>
                            <!-- Fungsi Unshift Array -->
                            <?php
                                echo '<h5>Unshift Array</h5>';
                                $tims = ["Kelinci","Ayam","Kucing","Ular"];
                                array_unshift($tims,"Bebek");
                                foreach($tims as $person) {
                                    echo '<ul>';
                                    echo '<li>'.$person . '</li>';
                                    echo '</ul>';
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    @nopall_donat
                </div>
                <!-- /.card-footer-->
            </div>
            <!-- /.card -->

        </section>
        <!-- /.content -->
    </div>
    <!-- Footer -->
    <?php $this->load->view('layout/footer') ?>

</div>

<!-- JS -->
<?php $this->load->view('layout/js') ?>