<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>

<!-- Main -->
<div class="wrapper">

    <div class="content-wrapper" style="min-height: 2838.8px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?= $title ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_1/pengantar"><?= $title ?></a></li>
                            <li class="breadcrumb-item active"> <?= $judul?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?= $title ?></h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                <?php
                    $ar_buah = ["Pepaya", "Mangga","Pisang","Jambu" ];

                    // Cek buah index ke 2
                    echo $ar_buah[2];

                    // Cek jumlah buah
                    echo '<br>Jumlah Buah '. count($ar_buah);
                    
                    // Cetak seluruh buah
                    echo '<ol>';
                    foreach($ar_buah as $buah){
                        echo '<li>'. $buah. '</li>';
                    }
                    echo '</ol>';

                    // Tambahkan buah
                    $ar_buah[] = "Durian";

                    // Hapus buah index ke 1
                    unset($ar_buah[1]);

                    // Ubah buah index ke 2 menjadi manggis
                    $ar_buah[2] = "Manggis";

                    // Cetak seluruh buah dengan indexnya
                    echo '<ul>';
                    foreach ($ar_buah as $k => $v) {
                        echo '<li>Buah index ke '. $k.' adalah '. $v.'</li>';
                    }
                    echo '</ul>';
                ?>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    @nopall_donat
                </div>
                <!-- /.card-footer-->
            </div>
            <!-- /.card -->

        </section>
        <!-- /.content -->
    </div>
    <!-- Footer -->
    <?php $this->load->view('layout/footer') ?>

</div>

<!-- JS -->
<?php $this->load->view('layout/js') ?>