<!-- Meta -->
<?php $this->load->view('layout/meta') ?>
<style>
    th, td {
        text-align: center;
    }
</style>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>

<!-- Main -->
<div class="wrapper">

    <div class="content-wrapper" style="min-height: 2838.8px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?= $title ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_1/pengantar"><?= $title ?></a></li>
                            <li class="breadcrumb-item active"> <?= $judul?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?= $title ?></h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <h2 class="text-center fw-bold pb-2 border-bottom border-2">Daftar Nilai Siswa</h2>
                    <table class="table table-hover text-nowrap kasih-border">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">NIM</th>
                                <th scope="col">UTS</th>
                                <th scope="col">UAS</th>
                                <th scope="col">Tugas</th>
                                <th scope="col">Nilai Akhir</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // object
                                $ns1 = ['id'=>1,'nim'=>'01101','uts'=>80,'uas'=>84,'tugas'=>78];
                                $ns2 = ['id'=>2,'nim'=>'01121','uts'=>70,'uas'=>50,'tugas'=>68];
                                $ns3 = ['id'=>3,'nim'=>'01130','uts'=>60,'uas'=>86,'tugas'=>70];
                                $ns4 = ['id'=>4,'nim'=>'01134','uts'=>90,'uas'=>91,'tugas'=>82];
                        
                                $ar_nilai = [$ns1, $ns2 , $ns3, $ns4];
                        
                                $nomor = 1;
                                foreach ($ar_nilai as $ns) {
                                    $_warna = ($nomor % 2 == 0) ? "yellow" : "pink";
                                    echo '<tr bgcolor="'.$_warna.'">';
                                    echo '<td scope="row">'.$nomor.'</td>';
                                    echo '<td>'.$ns['nim'].'</td>';
                                    echo '<td>'.$ns['uts'].'</td>';
                                    echo '<td>'.$ns['uas'].'</td>';
                                    echo '<td>'.$ns['tugas'].'</td>';
                                    $nilai_akhir = ($ns['uts'] + $ns['uas'] + $ns['tugas']) / 3;
                                    echo '<td>' . number_format($nilai_akhir,2,',','.').'</td>';
                                    echo '<tr/>';
                                    $nomor++;
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    @nopall_donat
                </div>
                <!-- /.card-footer-->
            </div>
            <!-- /.card -->

        </section>
        <!-- /.content -->
    </div>
    <!-- Footer -->
    <?php $this->load->view('layout/footer') ?>

</div>

<!-- JS -->
<?php $this->load->view('layout/js') ?>