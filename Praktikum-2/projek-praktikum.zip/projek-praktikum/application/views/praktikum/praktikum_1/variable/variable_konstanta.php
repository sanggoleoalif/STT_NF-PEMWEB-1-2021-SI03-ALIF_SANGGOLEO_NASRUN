<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>

<!-- Main -->
<div class="wrapper">

    <div class="content-wrapper" style="min-height: 2838.8px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?= $title ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_1/pengantar"><?= $title ?></a></li>
                            <li class="breadcrumb-item active"> <?= $judul?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?= $title ?></h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                    </div>
                        <div class="card-body">
                        <?php
                            // Definisikan Konstanta
                            define('PHI', 3.14);
                            define('DENAME', 'Inventori');
                            define('DESERVER', 'localhost');

                            $jari = 8;
                            $luas = PHI * $jari * $jari;
                            $kll = 2 * PHI * $jari;

                            echo '<p>Luas lingkaran dengan jari-jari '.$jari.'cm adalah '.$luas.'cm</p>';
                            echo "<p>Dengan keliling $kll cm</p>";
                            echo '<hr>';
                            echo '<p>Nama databasenya : '.DENAME.'</p>';
                            echo '<p>Lokasi databasenya ada di '.DESERVER.'</p>';
                        ?>
                        </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                    @nopall_donat
                </div>
                <!-- /.card-footer-->
            </div>
            <!-- /.card -->
        </section>
        <!-- /.content -->
    </div>
    <!-- Footer -->
    <?php $this->load->view('layout/footer') ?>

</div>

<!-- JS -->
<?php $this->load->view('layout/js') ?>