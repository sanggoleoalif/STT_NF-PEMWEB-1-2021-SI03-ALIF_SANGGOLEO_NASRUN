<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
    * {
        font-family: 'Times New Roman', Times, serif;
    }
    </style>
</head>

<body>

    <section class="content mt-4">
        <div class="container">
            <h4><?= $judul ?></h4>
            <div class="card p-5">
                <?php echo form_open('praktikum_7/dosen/view'); ?>
                    <div class="form-group row">
                        <label for="nim" class="col-4 col-form-label">NIDN</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nidn" name="nidn" placeholder="NIDN" type="number" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-align-left"></i>
                                    </div>
                                </div>
                                <input id="nama" name="nama" placeholder="Nama Lengkap Dosen" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-4">Jenis Kelamin</label>
                        <div class="col-8">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="jk" id="jk_0" type="radio" class="custom-control-input" value="L">
                                <label for="jk_0" class="custom-control-label">Laki-laki</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="jk" id="jk_1" type="radio" class="custom-control-input" value="P">
                                <label for="jk_1" class="custom-control-label">Perempuan</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-anchor"></i>
                                    </div>
                                </div>
                                <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                </div>
                                <input id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir" type="date"
                                    class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="prodi" class="col-4 col-form-label">Program Studi</label>
                        <div class="col-8">
                            <select id="prodi" name="prodi" class="custom-select">
                                <option value="TI">Teknik Informatika</option>
                                <option value="SI">Sistem Informasi</option>
                                <option value="BD">Bisnis Digital</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="ipk" class="col-4 col-form-label">Pendidikan Dosen</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-sort-numeric-desc"></i>
                                    </div>
                                </div>
                                <input id="pendidikan" name="pendidikan" placeholder="Pendidikan Dosen" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="offset-4 col-8">
                            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
                <?php echo form_open('praktikum_7/mahasiswa/view'); ?>
                    <div class="form-group row">
                        <label for="nim" class="col-4 col-form-label">NIM</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nim" name="nim" placeholder="NIM" type="number" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-align-left"></i>
                                    </div>
                                </div>
                                <input id="nama" name="nama" placeholder="Nama Lengkap" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-4">Jenis Kelamin</label>
                        <div class="col-8">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="jk" id="jk_0" type="radio" class="custom-control-input" value="L">
                                <label for="jk_0" class="custom-control-label">Laki-laki</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="jk" id="jk_1" type="radio" class="custom-control-input" value="P">
                                <label for="jk_1" class="custom-control-label">Perempuan</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-anchor"></i>
                                    </div>
                                </div>
                                <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                </div>
                                <input id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir" type="date"
                                    class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="prodi" class="col-4 col-form-label">Program Studi</label>
                        <div class="col-8">
                            <select id="prodi" name="prodi" class="custom-select">
                                <option value="TI">Teknik Informatika</option>
                                <option value="SI">Sistem Informasi</option>
                                <option value="BD">Bisnis Digital</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="ipk" class="col-4 col-form-label">IPK</label>
                        <div class="col-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-sort-numeric-desc"></i>
                                    </div>
                                </div>
                                <input id="ipk" name="ipk" placeholder="IPK" type="number" step="any" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="offset-4 col-8">
                            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
</body>
<?php
                                                        if(mhs->prodi == "TI") {
                                                            echo '<option value="TI">Teknik Informatika</option>';
                                                            echo '<option value="SI">Sistem Informasi</option>';
                                                            echo '<option value="BD">Bisnis Digital</option>';
                                                        } elseif (mhs->prodi == "SI") {
                                                            echo '<option value="SI">Sistem Informasi</option>';
                                                            echo '<option value="BD">Bisnis Digital</option>';
                                                            echo '<option value="TI">Teknik Informatika</option>';
                                                        } elseif (mhs->prodi == "BD") {
                                                            echo '<option value="BD">Bisnis Digital</option>';
                                                            echo '<option value="TI">Teknik Informatika</option>';
                                                            echo '<option value="SI">Sistem Informasi</option>';
                                                        }
                                                        
                                                    ?>
</html>