<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>SCRM</b>09
    </div>
    This Website Has Development by <strong>ScreameMost</strong>
</footer>