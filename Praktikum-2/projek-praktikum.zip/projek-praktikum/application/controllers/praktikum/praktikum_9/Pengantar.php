<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengantar extends CI_Controller {

    public function index() {
        $data['judul'] = 'Dashboard Praktikum 09';
        $data['title'] = 'Praktikum 9';
		$this->load->view('praktikum/praktikum_9/pengantar/index', $data);

    }

}
?>