<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Prodi extends CI_Controller {

        public function index() {

            $this->load->model('dbkampus/prodi_model', 'prodi');

            $data['judul'] = 'Tabel Prodi';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Prodi';
            
            $list_prodi = $this->prodi->getAll();
            $data['list_prodi'] = $list_prodi;
            

            $this->load->view('praktikum/praktikum_9/prodi/index.php', $data);

        }
    }
?>