<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {

	public function index() {
        $data['judul'] = 'Tabel Data Matakuliah';
        $data['title'] = 'Praktikum 6';
        $data['table'] = 'Matakuliah';

        $this->load->model("model_kuliah/matakuliah_model", "matkul1");
        $this->matkul1->id = 1;
        $this->matkul1->nama = "Pemograman Web";
        $this->matkul1->sks = 3;
        $this->matkul1->kode = "001";
        
        $this->load->model("model_kuliah/matakuliah_model", "matkul2");
        $this->matkul2->id = 2;
        $this->matkul2->nama = "Dasar-dasar Pemograman";
        $this->matkul2->sks = 3;
        $this->matkul2->kode = "002";
        
        $this->load->model("model_kuliah/matakuliah_model", "matkul3");
        $this->matkul3->id = 3;
        $this->matkul3->nama = "User Interface & User Experience";
        $this->matkul3->sks = 2;
        $this->matkul3->kode = "003";

        $this->load->model("model_kuliah/matakuliah_model", "matkul4");
        $this->matkul4->id = 4;
        $this->matkul4->nama = "Basis Data";
        $this->matkul4->sks = 3;
        $this->matkul4->kode = "004";
        
        $list_matkul = [$this->matkul1, $this->matkul2, $this->matkul3, $this->matkul4];
        $data['list_matkul'] = $list_matkul;
        

		$this->load->view('praktikum/praktikum_6/matakuliah/index', $data);

	}

}
