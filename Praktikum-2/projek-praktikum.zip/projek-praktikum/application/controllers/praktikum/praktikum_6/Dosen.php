<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

	public function index() {
        $data['judul'] = 'Tabel Data Mahasiswa';
        $data['title'] = 'Praktikum 6';
        $data['table'] = 'Dosen';

        $this->load->model("model_kuliah/dosen_model", "dsn1");
        $this->dsn1->nidn = "0012201";
        $this->dsn1->nama = "Ahmad Fauzi";
        $this->dsn1->tmp_lahir = "Banyuwangi";
        $this->dsn1->tgl_lahir = "01-12-1985";
        $this->dsn1->gender = "L";
        $this->dsn1->pendidikan = "S2";
        
        $this->load->model("model_kuliah/dosen_model", "dsn2");
        $this->dsn2->nidn = "0012202";
        $this->dsn2->nama = "Rahma Aulia";
        $this->dsn2->tmp_lahir = "Jakarta";
        $this->dsn2->tgl_lahir = "29-05-1987";
        $this->dsn2->gender = "P";
        $this->dsn2->pendidikan = "S2";

        $this->load->model("model_kuliah/dosen_model", "dsn3");
        $this->dsn3->nidn = "0012203";
        $this->dsn3->nama = "Ilhamsyah";
        $this->dsn3->tmp_lahir = "Banyuwangi";
        $this->dsn3->tgl_lahir = "14-11-1974";
        $this->dsn3->gender = "L";
        $this->dsn3->pendidikan = "S3";

        $this->load->model("model_kuliah/dosen_model", "dsn4");
        $this->dsn4->nidn = "0012204";
        $this->dsn4->nama = "Hafidz Yahya";
        $this->dsn4->tmp_lahir = "Pontianak";
        $this->dsn4->tgl_lahir = "21-06-1971";
        $this->dsn4->gender = "L";
        $this->dsn4->pendidikan = "S3";

        $this->load->model("model_kuliah/dosen_model", "dsn5");
        $this->dsn5->nidn = "0012205";
        $this->dsn5->nama = "Irawati";
        $this->dsn5->tmp_lahir = "Bali";
        $this->dsn5->tgl_lahir = "30-02-1969";
        $this->dsn5->gender = "P";
        $this->dsn5->pendidikan = "S3";


        $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3, $this->dsn4, $this->dsn5];
        $data['list_dsn'] = $list_dsn;
        
		$this->load->view('praktikum/praktikum_6/dosen/index', $data);
	}

}
