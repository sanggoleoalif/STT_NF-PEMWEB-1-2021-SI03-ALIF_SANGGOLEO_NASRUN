<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_array extends CI_Controller {

    public function array_buah() {
        $data['judul'] = 'Array Buah';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/file_array/array_buah.php', $data);
    }

    public function array_fungsi() {
        $data['judul'] = 'Array Fungsi';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/file_array/array_fungsi', $data);
    }

    public function array_fungsi2() {
        $data['judul'] = 'Array Fungsi 2';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/file_array/array_fungsi2.php', $data);
    }

    public function array_data() {
        $data['judul'] = 'Array Data';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/file_array/array_data.php', $data);
    }
}
?>