<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

    public function form() {
        $data['judul'] = 'Form Kelola Mahasiswa';
        $data['title'] = 'Praktikum 7';
        $data['table'] = 'Mahasiswa';
		$this->load->view('praktikum/praktikum_7/mahasiswa/form', $data);

    }

    public function view() {
        $data['judul'] = 'Table Kelola Mahasiswa';
        $data['title'] = 'Praktikum 7';
        $data['table'] = 'Mahasiswa';
        $this->load->model("model_kuliah/mahasiswa_model", "mhs");

        $this->mhs->nim = $this->input->post('nim');
        $this->mhs->nama = $this->input->post('nama');
        $this->mhs->gender = $this->input->post('jk');
        $this->mhs->tmp_lahir = $this->input->post('tmp_lahir');
        $this->mhs->tgl_lahir = $this->input->post('tgl_lahir');
        $this->mhs->prodi = $this->input->post('prodi');
        $this->mhs->ipk = $this->input->post('ipk');

        $data['mhs'] = $this->mhs;

		$this->load->view('praktikum/praktikum_7/mahasiswa/view', $data);

    }
}
?>