<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Login extends CI_Controller {

        public function index() {	
            $data['title'] = 'Login';
            $this->load->view('user/login.php', $data);
        }

        public function authentication() {
            $this->load->model('user/user_model', 'user');
            // $list_mhs = $this->mhs->getAll();
            // $data['list_mhs'] = $list_mhs;

            $uname = $this->input->post('username');
            $pass = $this->input->post('password');

            $row = $this->user->login($uname, $pass);

            if(isset($row)) {
                
                $this->session->set_userdata('USERNAME', $row->username);
                $this->session->set_userdata('FULLNAME', $row->fullname);
                $this->session->set_userdata('ROLE', $row->role);
                $this->session->set_userdata('USER', $row);

                redirect(base_url("index.php"), 'refresh');
            } else {
                redirect(base_url("index.php/user/login?status=f"), 'refresh');
            }
        }

}
