<?php
    class Matakuliah_model extends CI_model {
        public $id;
        public $kode;
        public $nama;
        public $sks;
    }
?>